import pygame, sys, random
from pygame.math import Vector2

pygame.init()
GREEN = (173, 204, 96)
cell_size = 30
number_of_cells = 25

class Food:
    def __init__(self, snake_body):
        self.position = self.generate_random_pos(snake_body)

    def draw(self):
        food_rect = pygame.Rect(self.position.x * cell_size, self.position.y * cell_size, cell_size, cell_size)
        screen.blit(food_surface, food_rect)

    def generate_random_cell(self):
        x = random.randint(0, number_of_cells - 1)
        y = random.randint(0, number_of_cells - 1)
        return Vector2(x, y)

    def generate_random_pos(self, snake_body):
        position = self.generate_random_cell()
        while position in snake_body:
            position = self.generate_random_cell()
        return position

class Snake_Segment: # create class specifically for each snake segment
    def __init__(self, position, color):
        self.position = position
        self.color = color

class Snake:
    def __init__(self):
        # create three segments for starter 
        self.body = [Snake_Segment(Vector2(6, 9), (255)),
                     Snake_Segment(Vector2(5, 9), (255)),
                     Snake_Segment(Vector2(4, 9), (255))]
        self.direction = Vector2(1, 0)
        self.add_segment = False

    def draw(self):
        for segment in self.body:
            segment_rect = pygame.Rect(segment.position.x * cell_size, segment.position.y * cell_size, cell_size, cell_size)
            pygame.draw.rect(screen, segment.color, segment_rect, 0, 7)

    def update(self):
        self.body.insert(0, Snake_Segment(self.body[0].position + self.direction, (255, 255, 255)))
        if self.add_segment:
            self.add_segment = False
            # Generate random color for the new segment
            randcolor = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
            self.body[0].color = randcolor
        else:
            self.body = self.body[:-1]

    def reset(self):
        self.body = [Snake_Segment(Vector2(6, 9), (255)),
                     Snake_Segment(Vector2(5, 9), (255)),
                     Snake_Segment(Vector2(4, 9), (255))]
        self.direction = Vector2(1, 0)

class Game:
    def __init__(self):
        self.snake = Snake()
        self.food = Food([segment.position for segment in self.snake.body])
        self.state = "RUNNING"
        self.score = 0

    def draw(self):
        self.food.draw()
        self.snake.draw()
        self.display_score()

    def update(self):
        if self.state == "RUNNING":
            self.snake.update()
            self.check_collision_with_food()
            self.check_collision_with_edges()
            self.check_collision_with_tail()

    def display_score(self):
        font = pygame.font.Font(None, 30)
        score_text = font.render(f"Your Score: {self.score}", True, 255)
        screen.blit(score_text, (10, 10))

    def check_collision_with_food(self):
        if self.snake.body[0].position == self.food.position:
            print("Eating food")
            self.score += 1 # increase score by one when food is eaten 
            self.food.position = self.food.generate_random_pos([segment.position for segment in self.snake.body])
            self.snake.add_segment = True

    def check_collision_with_edges(self):
        if self.snake.body[0].position.x == number_of_cells or self.snake.body[0].position.x == -1:
            self.game_over()
        if self.snake.body[0].position.y == number_of_cells or self.snake.body[0].position.y == -1:
            self.game_over()

    def game_over(self):
        self.snake.reset()
        self.food.position = self.food.generate_random_pos([segment.position for segment in self.snake.body])
        self.state = "STOPPED"
        #reset score to 0
        self.score = 0

    def check_collision_with_tail(self):
        headless_body = self.snake.body[1:]
        if self.snake.body[0].position in [segment.position for segment in headless_body]:
            self.game_over()

screen = pygame.display.set_mode((cell_size * number_of_cells, cell_size * number_of_cells))
pygame.display.set_caption("560 Snake Game")
clock = pygame.time.Clock()

game = Game()
food_surface = pygame.image.load("graphics/food.png")


SNAKE_UPDATE = pygame.USEREVENT
pygame.time.set_timer(SNAKE_UPDATE, 200)

while True:
    for event in pygame.event.get():
        if event.type == SNAKE_UPDATE:
            game.update()
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP and game.snake.direction != Vector2(0, 1):
                game.snake.direction = Vector2(0, -1)
            if event.key == pygame.K_DOWN and game.snake.direction != Vector2(0, -1):
                game.snake.direction = Vector2(0, 1)
            if event.key == pygame.K_LEFT and game.snake.direction != Vector2(1, 0):
                game.snake.direction = Vector2(-1, 0)
            if event.key == pygame.K_RIGHT and game.snake.direction != Vector2(-1, 0):
                game.snake.direction = Vector2(1, 0)
            if game.state == "STOPPED":
                game.state = "RUNNING"

    screen.fill(GREEN)
    game.draw()

    pygame.display.update()
    clock.tick(10)
#code is cleaned up 
#segment of snakes get randomized one integration through when the snake eats food
#there is now a score counter everytime that the snake eats food
#score gets reset when the game is over 